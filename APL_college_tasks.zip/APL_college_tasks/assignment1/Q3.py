nums = [1, 2, 3, 4, 5]

result = list(map(lambda n: (n ** 2) + 10, nums))

print(result)